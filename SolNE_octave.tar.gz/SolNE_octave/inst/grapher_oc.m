function [] = grapher_oc(axis_x, axis_y, title_name)
  %{
  Makes graphs to see Iterations vs |f(x)| evaluations
  :param axis_x: Array with numeric values to x axis
  :param axis_y: Array with numeric values to y axis
  :param title: String - graph's name
  :return: Shows graph
  %}
  plot(axis_x, axis_y);
  
  xlabel("Iterations");
  ylabel("|f(x)|");
  title(title_name);
  
endfunction
