function [xaprox, iter] = sne_ud_6(f, x0, d, tol, graf = 1)
  %{
  sne_ud_6 will compute an aproximation of the root of a function. The
  Householder's Methods are a class of root-finding algorithms that differ from
  each other by a specific value d, that determines the order of the derivatives
  in this method.
  Is also a generalization of various famous root-finding methods (d = 1 is for
  the Newton-Raphson's Method, d = 2 for the Halley's Method, ...).
  
  Retrieved from: Alston Scott (1970). The Numerical Treatment Of A Single
  Nonlinear Equation, Pag. 169.
  
  f must be a string with the symbolic expression of the function to analize
  x0 must be the initial value
  d must be the order of the Householder's Method
  tol is the value that represents the precision required on the solution
  graf determines if the method needs to return a graph. Is 1 by default
  
  xaprox will be the aproximation of the zero
  iter will be the necessary amount of iterations to find the solution
  
  You need to install the symbolic package to use this method, and when you
  open Octave you have to execute the next lines to import the package and
  its functions:
  
  'pkg load symbolic;'
  'syms x;'
  
  :example: 'sne_ud_6("x ** 2 - 2", 1, 1, 0.0001);'
  %}
  pkg load symbolic;
  syms x;
  
  if(!ischar(f))
    printf("The initial value 'f' must be a string!\n");
    return
  endif
  fHandle = 0;
  try
    f = sym(f);
    fHandle = function_handle(f);
    fHandle(1);
  catch
    printf("Syntax Error!\n");
    return
  end
  
  format long;
  warning('off','Octave:divide-by-zero');
  if(iscomplex(x0) || iscomplex(tol))
    printf("The initial values 'x0' and 'tol' must be real numbers!\n");
    return
  endif
  
  if((floor(d) != abs(d)) && (d <= 0))
    printf("The initial value 'd' must be an integer!\n");
    return
  endif
  
  n = 1;
  numerator = 1 / f;
  denominator = 1 / f;
  while(n < d)
    numerator = diff(numerator);
    denominator = diff(denominator);
    n = n + 1;
  endwhile
  denominator = diff(denominator);
  numeratorHandle = function_handle(numerator);
  denominatorHandle = function_handle(denominator);
  
  xk = x0;
  k = 0;
  xVector = [k];
  yVector = [abs(fHandle(xk))];
  while(abs(fHandle(xk)) > tol)
    if((abs(numeratorHandle(xk)) == Inf) || (abs(denominatorHandle(xk)) == Inf))
      printf("You can't divide by zero!\nThe process has been stopped!\n");
      warning('on','Octave:divide-by-zero');
      xaprox = xk
      iter = k
      if(graf == 1)
        grapher_oc(xVector, yVector, "Householder's method to: f(x)")
      endif
      return
    endif
    xk = xk + d * (numeratorHandle(xk) / denominatorHandle(xk));
    
    k = k + 1;
    xVector = [xVector k];
    yVector = [yVector abs(fHandle(xk))];
  endwhile
  
  xaprox = xk
  iter = k
  if(graf == 1)
    grapher_oc(xVector, yVector, "Householder's method to: f(x)")
  endif
endfunction
