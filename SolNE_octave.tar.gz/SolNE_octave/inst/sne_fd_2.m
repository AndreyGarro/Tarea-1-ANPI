function [valorX, iter] = sne_fd_2(fun, x_a, x_b, tol, graph)
  %{
  Muller-Bisection Method
  It uses an interval from x_a to x_b to find an aproximation of x
  to resolve the function (fn) given by the user. It uses the Muller�s Method
  to find the new value of a third point, under the condition that this value 
  have to be between a new subroutine interval, if the value isn't here it uses
  the Bisection's Method.
  
  Retrieved from: Wu, Xinyuan. (2005). Improved Muller method and Bisection method with global and asymptotic
  superlinear convergence of both point and interval for solving nonlinear equations. Avalaible at:
  https://tecdigital.tec.ac.cr/dotlrn/classes/IDC/CE3102/S-2-2019.CA.CE3102.1/
  file-storage/view/Tareas%2Ftarea-1%2Fart-culos-cient-ficos%2F1-s2.0-S0096300304004382-main.pdf
  
  :param x_a: initial value for the interval
  :param x_b: final value for the interval
  :param x_b: final value for the interval
  :param fun: math expression to evaluate
  :param tol: minimum approach tolerance
  :param graph: Integer, 1 or 0
  :return: Tuple, [x aproximation, iterations]
  %}
  pkg load symbolic;
  syms x;
  fun = sym(fun);
  
  if ~(isfloat(x_a) || isinteger(x_a) || isinteger(x_b) || isfloat(x_b))
    print("Error, interval its not valid")
    return
  endif
  if ~(isfloat(tol) || isinteger(tol))
    print("Error, tolerance isn't a valid number")
    return
  endif
  
  variable = symvar(fun);
  if (length(variable) > 1)
    disp("Error: The f expression has more than one variables");
    return;
  endif
  if (isempty(find(x == variable)))
    disp("Error: The expression f doesn't have x as a variable");
    return;
  endif
  
  funHandler = function_handle(fun);
  x_c = x_a + (x_b - x_a) / 2;
  x_aa = 0;
  x_bb = 0;
  iterations = 0;
  x_values = [iterations];
  y_values = [abs(funHandler(x_c))];

  #Function Evaluation
  x_a_eval = funHandler(x_a);
  x_b_eval = funHandler(x_b);
  x_c_eval = funHandler(x_c);

  #Validations
  if(x_a > x_b)
      disp("Error, enter a valid interval");
      return;
  elseif x_a_eval * x_b_eval > 0
      disp("The existence of one or a single zero in the given interval cannot be guaranteed.");
      return;
  endif
  
  #Subroutine interval
  if x_c_eval == 0
      valorX = x_c
  elseif x_a_eval * x_c_eval < 0
      x_aa = x_a;
      x_bb = x_c;
  elseif x_b_eval * x_c_eval < 0
      x_aa = x_c;
      x_bb = x_b;
  endif

  x_c_new = mullerAlgorithm(x_a, x_b, x_c, fun);
  while(abs(funHandler(x_c_new)) >= tol)
    x_aa_eval = funHandler(x_aa);
    x_bb_eval = funHandler(x_bb);
    x_new_eval = funHandler(x_c_new);

    if x_aa < x_c_new < x_bb
        if x_c_new == 0
            valorX = x_c_new
        elseif x_aa_eval * x_new_eval < 0
            x_aa = x_a;
            x_bb = x_c_new;
        elseif x_bb_eval * x_new_eval < 0
            x_aa = x_c_new;
            x_bb = x_b;
        endif
    else
        x_c = x_aa + (x_bb - x_aa) / 2;
    endif
    iterations = iterations + 1;
    x_c_new = mullerAlgorithm(x_aa, x_bb, x_c, fun);
    x_values = [x_values iterations];
    y_values = [y_values abs(funHandler(x_c_new))];
  endwhile
  if(graph == 1)
    grapher_oc(x_values, y_values, "Muller-Bisection method to f(x)");
  elseif (graff != 0)
    disp("Warning: parameter graff must be an integer, 1 or 0");
  endif
  valorX = x_c_new
  iter = iterations
endfunction

function x_sol = mullerAlgorithm(x_a, x_b, x_c, fun)
  %{
  Muller Algorithm
  It's the part needed of the algorithm for the method.
  :param x_a: first value of x.
  :param x_b: second value of x.
  :param x_c: third value of x.
  :param fun: math expression to evaluate.
  :return: the better aproximation of a new point.
  %}
  funHandler = function_handle(fun);
  x_a_eval = funHandler(x_a);
  x_b_eval = funHandler(x_b);
  x_c_eval = funHandler(x_c);
  
  matrix = [x_a**2, x_a 1; x_b**2, x_b 1; x_c**2, x_c 1];
  
  res = [x_a_eval; x_b_eval; x_c_eval];
  
  sysSolve = inv(matrix)*res;
  A = sysSolve(1,1);
  B = sysSolve(2,1);
  C = sysSolve(3,1);
  
  discri=sqrt ( B**2 - 4 * A * C) ;
  x1 = (-B + discri ) / (2 * A);
  x2 = (-B - discri ) / (2 * A);
  
  sum0 = calculateDistance(x_a, x_b, x_c, x1);
  sum1 = calculateDistance(x_a, x_b, x_c, x2);
  
  if(sum0 <= sum1)
    x_sol = x1;
  else
    x_sol = x2;
  endif  
endfunction

function sum = calculateDistance(a,b,c,d)
  %{
  Calculates the nearest point to the other.
  :param a: existing point
  :param b: existing point
  :param c: existing point
  :param d: new point to compare
  %}
    sum_dist_a = abs(a - d);
    sum_dist_b = abs(b - d);
    sum_dist_c = abs(c - d);

    total_sum = sum_dist_a + sum_dist_b + sum_dist_c;

    if sum_dist_a >= sum_dist_b && sum_dist_a >= sum_dist_c
        sum = total_sum-sum_dist_a;
    elseif sum_dist_b >= sum_dist_a && sum_dist_b >= sum_dist_c
        sum = total_sum-sum_dist_b;
    else
        sum = total_sum-sum_dist_c;
    endif
endfunction
