function [] = sne_ud_2(f, xk, tol, graff=1)
  pkg load symbolic;
  syms x;
  %{
  This function find solution to non lineal equation using Kou-Li's method.
  Kou-Li's method use an inicitial value(x0) to start solving the equation.

  Retrieved from: Prieto J.(2008) METODOS ITERATIVOS PARA RESOLVER
  ECUACIONES NO LINEALES. Tesis de Licenciatura. Universidad de Los Andes.

  Function Format: sne_ud_1(f, xk, tol, graff)
  
  :param f: Type STRING. Math expression to evaluate
  :param xk: Type FLOAT or INTEGER. Initial value for X
  :param tol: Type FLOAT or INTEGER. Minimum approach tolerance
  :param graff: Type INTEGER. Indicates if you want a graph or not.
    Its an optional parameter
  :return: x, iterations
  %}
  if(!ischar(f))
    printf("The initial value 'f' must be a string!\n");
    return
  endif
  try
    f = sym(f);
    fn = function_handle(f);
    fn(1);
  catch
    printf("Syntax Error!\n");
    return
  end
  
  df = function_handle(diff(f));
  if (diff(f) != 0)
    if (isfloat(xk) || isinteger(xk))
      if (isfloat(tol) || isinteger(tol))
        fk = fn(xk);
        dfk = df(xk);
        iter = 0;
        x_values = [iter];
        y_values = [abs(fk)];
        while (abs(fk) > tol)
          if (dfk == 0)
            break;
          endif
          
          yk = xk - (fk / (2*dfk));
          if (df(yk)-dfk == 0)
            break;
          endif
          
          xk = xk - (fk / 2) * (1 / dfk + 1 / (2*df(yk) - dfk));

          fk = fn(xk);
          dfk = df(xk);

          iter += 1;
          
          x_values = [x_values iter];
          y_values = [y_values abs(fk)];
        endwhile
        if (graff == 1)
          grapher_oc(x_values, y_values, "Kouli's method to f(x)");
        elseif (graff != 0)
          disp("Warning: parameter graff must be an integer, 1 or 0");   
        endif
        x = xk
        iter = iter
      else
        disp("'tol' type error, must be float or integer");
      endif
    else
      disp("'xk' type error, must be float or integer");
    endif
  else
    disp("Error: f derivative must be different from 0");
  endif
endfunction
