
function [x_sig, iteraciones] = sne_fd_3(f, x2, x1, x0, tol, graff = 1)
  pkg load symbolic;
  syms x;
  %{
  Inverser quadratic interpolation's method consists in aproximated the inverse of f, the method need
    three initial values, integers o floats. The return of method is the value aproximate for x and the number
    of iterations. 
    
    Reference: Mark James Magnaye, M. J. B. M. (n.d.-a). Inverse Quadratic Interpolation Method. 
    Retrieved August 20, 2019, from https://www.academia.edu/8121176/Inverse_Quadratic_Interpolation_Method
    
        
    Function Format: sne_ud_#(f, x2, x1, x0, tol, graff)
    
    :param x2: (Type FLOAT/ INTEGER) First initial Value
    :param x1: (Type FLOAT/ INTEGER) Second initial Value
    :param x0: (Type FLOAT/ INTEGER) Third initial Value
    :param tol:(Type FLOAT/ INTEGER) approach tolerance
    :param f: (Type STRING) math function
    :param graff: (Type INTEGER) 1 to shown the graphic and 0 to don't shown
    :return: (Type TUPLE X) approximate and number of iterations
  %}
  if(isinteger(x1) == 0 && isfloat(x1) == 0 
  && isinteger(x1) == 0 && isfloat(x1 == 0)
  && isinteger(x0) == 0 && isfloat(x0) == 0)
    disp("Error: Incorrect initial value");
    return;
  endif
  if(isinteger(tol) == 0 && isfloat(tol) == 0)
    disp("Error: Incorrect tolerance");
    return;    
  endif
  f = sym(f);
  variable = symvar(f);
  if (length(variable) > 1)
    disp("Error: The f expression has more than one variables");
    return;
  endif
  if (isempty(find(x == variable)))
    disp("Error: The expression f doesn't have x as a variable");
    return;
  endif
  fh = function_handle(f);
  divisor_termino1 = (fh(x0) - fh(x1)) * (fh(x0) - fh(x2));
  divisor_termino2 = (fh(x1) - fh(x0)) * (fh(x1) - fh(x2));
  divisor_termino3 = (fh(x2) - fh(x0)) * (fh(x2) - fh(x1));
  if (divisor_termino1 == 0 || 
    divisor_termino2 == 0 || 
    divisor_termino3 == 0)
    disp("Error: Division by zero");
    return;
  endif
  termino1 = (fh(x1) * fh(x2) * (x0) / divisor_termino1);
  termino2 = (fh(x0) * fh(x2) * (x1) / divisor_termino2);
  termino3 = (fh(x0) * fh(x1) * (x2) / divisor_termino3);
  x_sig = termino1 + termino2 + termino3;
  iteraciones = 1;
  valores_x = [iteraciones];
  valores_y = [abs(fh(x_sig))];
  while(abs(x_sig  - x1) >= tol)
    x0 = x1;
    x1 = x2;
    x2 = x_sig;
    divisor_termino1 = (fh(x0) - fh(x1)) * (fh(x0) - fh(x2));
    divisor_termino2 = (fh(x1) - fh(x0)) * (fh(x1) - fh(x2));
    divisor_termino3 = (fh(x2) - fh(x0)) * (fh(x2) - fh(x1));
    if (divisor_termino1 == 0 || 
      divisor_termino2 == 0 || 
      divisor_termino3 == 0)
      disp("Error: Division by zero");
      return;
    endif
    termino1 = (fh(x1) * fh(x2) * (x0) / divisor_termino1);
    termino2 = (fh(x0) * fh(x2) * (x1) / divisor_termino2);
    termino3 = (fh(x0) * fh(x1) * (x2) / divisor_termino3);
    x_sig = termino1 + termino2 + termino3;
    iteraciones += 1;
    valores_x = [valores_x iteraciones];
    valores_y = [valores_y abs(fh(x_sig))];        
  endwhile
  if (graff == 1)
    grapher_oc(valores_x, valores_y,(
    "Inverse Quadratic Interpoletion's Method: f(x)"));
  elseif (graff != 0)
    disp("Warning: parameter graff must be an integer, 1 or 0");    
  endif  
endfunction
