
function [x4, iteraciones] = sne_fd_4(f, a, b, tol, graff = 1)
  pkg load symbolic;
  syms x;
  %{
  The Ridders method is based on the method a false position to calculate the root of x, this 
   method uses an exponential function to adjust the value of x. The funtion need an initial interval 
   where there is a zero of the function and returns an approximate value a that zero.
   
    Reference:Modesto Mas, M. M. (2016b, June 24). Ridders' method in Julia. 
    Retrieved August 25, 2019, from https://mmas.github.io/ridders-julia
    
    Function Format: sne_ud_#(f, a, b, tol, graff)
    
    :param a: (Type INTEGER/ FLOAT) Initial interval point
    :param b: (Type INTEGER/ FLOAT) End interval point
    :param tol: (Type INTEGER/ FLOAT) approach tolerance
    :param f: (Type STRING)math function
    :param graff: (Type INTEGER/ FLOAT) Integer, 1 to shown the graphic and 0 to don't shown
    :return: (Type TUPLE) x approximate and number of iterations
  %}
  if(isinteger(a) == 0 && isfloat(b) == 0 &&
  isinteger(b) == 0 && isfloat(b) == 0)
    disp("Error: Incorrect initial value");
    return;
  endif
  if(isinteger(tol) == 0 && isfloat(tol) == 0)
    disp("Error: Incorrect tolerance");
    return;    
  endif
  f = sym(f);
  variable = symvar(f);
  if (length(variable) > 1)
    disp("Error: The f expression has more than one variables");
    return;
  endif
  if (isempty(find(x == variable)))
    disp("Error: The expression f doesn't have x as a variable");
    return;
  endif
  x1 = a;
  x2 = b;
  fh = function_handle(f);
  iteraciones = 1;
  x3 = (x1 + x2)/2;
  signo = (fh(x1) - fh(x2)) / abs(fh(x1) - fh(x2));
  x4 = (x3 + signo * (fh(x3) * (x3 - x1) / 
  sqrt(fh(x3)**2 - fh(x1) * fh(x2))));
  valores_x = [iteraciones];
  valores_y = [abs(fh(x4))];
  while(abs(fh(x4)) >= tol)
    if(fh(x4) >= 0)
      x2 = x4;
    else 
      x1 = x4;
    endif
    x3 = (x1 + x2)/2;
    signo = ((fh(x1) - fh(x2)) / abs(fh(x1) - fh(x2)));
    x4 = (x3 + signo * (fh(x3) * (x3 - x1) / 
    sqrt(fh(x3)**2 - fh(x1) * fh(x2))));
    iteraciones += 1;
    valores_x = [valores_x iteraciones];
    valores_y = [valores_y abs(fh(x4))];
  endwhile
  if (graff == 1)
    grapher_oc(valores_x, valores_y, "Halley's method");
  elseif (graff != 0)
    disp("Warning: parameter graff must be an integer, 1 or 0");    
  endif  
endfunction
