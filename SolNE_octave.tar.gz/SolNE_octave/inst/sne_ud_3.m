function [valorX, iter] = sne_ud_3(func, xo, tol, graph)
  %{
  Modified Newton Raphson Method
  This method csonsists in taking the known method of Newton Raphson, but with 
  variation in its formula, this variation is adding the second derivate. This 
  method has a faster convergence the normal NR.
    
  Retrieved from: Calder�n, G. (2008). M�todos iterativos para resolver 
  ecuaciones no lineales. [online]Available at: 
  http://webdelprofesor.ula.ve/ciencias/giovanni/documentos/Publicaciones/
  Articulos/NotasMatematicasV32007.pdf
  
  :parameter xo: initial value for 'x'
  :param func: math expression to evaluate
  :param tol: minimum approach tolerance
  :param graph: Integer, 1 or 0
  :return: Tuple, [x aproximation, iterations]
  %}

  pkg load symbolic;
  syms x;
  func = sym(func);
  
  if ~(isfloat(xo) || isinteger(xo))
    print("Error, interval its not valid")
    return;
  endif;
  if ~(isfloat(tol) || isinteger(tol))
    print("Error, tolerance isn't a valid number");
    return;
  endif
  variable = symvar(func);
  if (length(variable) > 1)
    disp("Error: The f expression has more than one variables");
    return;
  endif
  if (isempty(find(x == variable)))
    disp("Error: The expression f doesn't have x as a variable");
    return;
  endif
  
  variable = symvar(func);
  if (length(variable) > 1)
    disp("Error: The f expression has more than one variables");
    return;
  endif
  if (isempty(find(x == variable)))
    disp("Error: The expression f doesn't have x as a variable");
    return;
  endif
  
  first_dfuncion = diff(func);
  sec_dfuncion = diff(first_dfuncion);
  funHandler = function_handle(func);
  first_dfunHandler = function_handle(first_dfuncion);
  sec_dfunHandler = function_handle(sec_dfuncion);
  
  iterations = 0;
  xVector = [];
  yVector = [];
  if(first_dfuncion == 0)
    printf("Derivate cannot be equal to zero");
  endif
  
  if(abs(funHandler(xo)) <= tol)
    valorX = xo
  else
    while(true)
      xVector(iterations+1) = iterations+1;
      yVector(iterations+1) = abs(funHandler(xo));
      if (abs(funHandler(xo)) <= tol)
         valorX = xo
         iter = iterations
         if (graph == 1)
          grapher_oc(xVector, yVector, "Modified Newton Raphson method to f(x)");
        elseif (graph != 0)
          disp("Warning: parameter graff must be an integer, 1 or 0");    
        endif
         break;
      else
         denominator = (first_dfunHandler(xo)) ** 2 - (funHandler(xo) * sec_dfunHandler(xo));
         if(denominator == 0)
            printf("Error. Denominator equal to zero");
            break;
         else
            xo =  xo - (funHandler(xo) * first_dfunHandler(xo)) / (denominator);
            iterations = iterations + 1;
         endif
      endif
     endwhile
  endif 
endfunction