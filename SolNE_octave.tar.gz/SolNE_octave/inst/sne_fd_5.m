function [xaprox, iter] = sne_fd_5(f, x0, x1, tol, graf = 1)
  %{
  sne_fd_5 will compute an aproximation of the root of a function. This
  method uses the concepts of the Bisection Method, the Secant Method and the 
  Inverse Quadratic Interpolation Algorithm.
  The Brent-Dekker's Method analyze a series of condition in order to select
  which of the three previous method is going to use for the next iteration.
  
  Retrieved from: Zhengqiu Zhang (2011). An Improvement to the Brent�s Method,
  International Journal of Experimental Algorithms (IJEA), Volume 2. Chinese
  Academy of Meteorological Sciences.
  
  f must be a string with the symbolic expression of the function to analize
  x0 must be the first initial value
  x1 must be the second initial value
  tol is the value that represents the precision required on the solution
  graf determines if the method needs to return a graph. Is 1 by default
  
  xaprox will be the aproximation of the zero
  iter will be the necessary amount of iterations to find the solution
  
  You need to install the symbolic package to use this method, and when you
  open Octave you have to execute the next lines to import the package and
  its functions:
  
  'pkg load symbolic;'
  'syms x;'
  
  :example: 'sne_fd_5("x ** 2 - 2", 1, 2, 0.0001);'
  %}
  pkg load symbolic;
  syms x;
  
  if(!ischar(f))
    printf("The initial value 'f' must be a string!\n");
    return
  endif
  fHandle = 0;
  try
    f = sym(f);
    fHandle = function_handle(f);
    fHandle(1);
  catch
    printf("Syntax Error!\n");
    return
  end
  
  format long;
  warning('off','Octave:divide-by-zero');
  if(iscomplex(x0) || iscomplex(x1) || iscomplex(tol))
    printf("The initial values 'x0', 'x1' and 'tol' must be real numbers!\n");
    return
  endif
  
  bolzano = fHandle(x0) * fHandle(x1);
  xk = x0;
  k = 0;
  xVector = [k];
  yVector = [abs(fHandle(xk))];
  if(bolzano > 0)
    printf(["Error: The existence of a zero can't be guaranteed by the " ...
            "Bolzano's Theorem!\n"]);
  else
    if(abs(fHandle(x0)) < abs(fHandle(x1)))
      temp = x1;
      x1 = x0;
      x0 = temp;
    endif
    
    xk = x0;
    x2 = x0;
    x3 = x0;
    flag = 1;
    while(abs(fHandle(xk)) > tol)
      if((fHandle(x0) != fHandle(x2)) && (fHandle(x1) != fHandle(x2)))
        t1 = (x0 * fHandle(x1) * fHandle(x2)) ...
        / ((fHandle(x0) - fHandle(x1)) * (fHandle(x0) - fHandle(x2)));
        t2 = (fHandle(x0) * x1 * fHandle(x2)) ...
        / ((fHandle(x1) - fHandle(x0)) * (fHandle(x1) - fHandle(x2)));
        t3 = (fHandle(x0) * fHandle(x1) * x2) ...
        / ((fHandle(x2) - fHandle(x0)) * (fHandle(x2) - fHandle(x1)));
        if((abs(t1) == Inf) || (abs(t2) == Inf) || (abs(t3) == Inf))
          printf("You can't divide by zero!\nThe process has been stopped!\n");
          warning('on','Octave:divide-by-zero');
          xaprox = xk
          iter = k
          if(graf == 1)
            grapher_oc(xVector, yVector, "Brent-Dekker's method to: f(x)")
          endif
          return
        endif
        xk = t1 + t2 + t3;
      else
        denominator = fHandle(x1) - fHandle(x0);
        if(abs(denominator) == Inf)
          printf("You can't divide by zero!\nThe process has been stopped!\n");
          warning('on','Octave:divide-by-zero');
          xaprox = xk
          iter = k
          grapher_oc(xVector, yVector, "Brent-Dekker's method to: f(x)")
          return
        endif
        xk = x1 - fHandle(x1) * ((x1 - x0) / denominator);
      endif
      
      if(((xk < ((3 * x0 + x1) / 4)) && (xk > x1)) || ...
         (flag && (abs(xk - x1) >= abs((x1 - x2) / 2))) || ...
         (!flag && (abs(xk - x1) >= abs((x2 - x3) / 2))) || ...
         (flag && (abs(x1 - x2) < abs(tol))) || ...
         (!flag && (abs(x2 - x3) < abs(tol))))
         
        xk = (x0 + x1) / 2;
        flag = 1;
      else
        flag = 0;
      endif
      x3 = x2;
      x2 = x1;
      
      bolzano = fHandle(x0) * fHandle(xk);
      if(bolzano <= 0)
        x1 = xk;
      else
        x0 = xk;
      endif
      
      if(abs(fHandle(x0)) < abs(fHandle(x1)))
        temp = x1;
        x1 = x0;
        x0 = temp;
      endif
      
      k = k + 1;
      xVector = [xVector k];
      yVector = [yVector abs(fHandle(xk))];
    endwhile
    
    xaprox = xk
    iter = k
    if(graf == 1)
      grapher_oc(xVector, yVector, "Brent-Dekker's method to: f(x)")
    endif
  endif
endfunction
