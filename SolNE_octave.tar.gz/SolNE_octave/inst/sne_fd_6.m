function [xaprox, iter] = sne_fd_6(f, x0, x1, tol, graf = 1)
  %{
  sne_fd_6 will compute an aproximation of the root of a function. This
  method is an improvement of the Regula Falsi Method. It helps when the
  conditions of slow convergence on the Regula Falsi Method are present by
  decreasing the effect of the function evaluated in the endpoint retained in
  the previous iteration.
  
  Retrieved from: S�rgio Galdino (2011). A family of regula falsi root-finding
  methods, Proceedings of 2011 World Congress on Engineering and Technology,
  Volume 1.
  
  f must be a string with the symbolic expression of the function to analize
  x0 must be the first initial value
  x1 must be the second initial value
  tol is the value that represents the precision required on the solution
  graf determines if the method needs to return a graph. Is 1 by default
  
  xaprox will be the aproximation of the zero
  iter will be the necessary amount of iterations to find the solution
  
  You need to install the symbolic package to use this method, and when you
  open Octave you have to execute the next lines to import the package and
  its functions:
  
  'pkg load symbolic;'
  'syms x;'
  
  :example: 'sne_fd_6("x ** 2 - 2", 1, 2, 0.0001);'
  %}
  pkg load symbolic;
  syms x;
  
  if(!ischar(f))
    printf("The initial value 'f' must be a string!\n");
    return
  endif
  fHandle = 0;
  try
    f = sym(f);
    fHandle = function_handle(f);
    fHandle(1);
  catch
    printf("Syntax Error!\n");
    return
  end
  
  format long;
  warning('off','Octave:divide-by-zero');
  if(iscomplex(x0) || iscomplex(x1) || iscomplex(tol))
    printf("The initial values 'x0', 'x1' and 'tol' must be real numbers!\n");
    return
  endif
  
  bolzano = fHandle(x0) * fHandle(x1);
  xk = x0;
  k = 0;
  xVector = [k];
  yVector = [abs(fHandle(xk))];
  if(bolzano > 0)
    printf(["Error: The existence of a zero can't be guaranteed by the " ...
            "Bolzano's Theorem!\n"]);
  else
    xk_1 = x0;
    sign = 0;
    while(abs(fHandle(xk)) > tol)
      if(k == 0)
        denominator = fHandle(x1) - fHandle(x0);
        if(abs(denominator) == Inf)
          printf("You can't divide by zero!\nThe process has been stopped!\n");
          warning('on','Octave:divide-by-zero');
          xaprox = xk
          iter = k
          if(graf == 1)
            grapher_oc(xVector, yVector, "Anderson-Bjorck's method to: f(x)")
          endif
          return
        endif
        xk = (x0 * fHandle(x1) - x1 * fHandle(x0)) / denominator;
      
      else
        if(abs(fHandle(xk_1)) == Inf)
          printf("You can't divide by zero!\nThe process has been stopped!\n");
          warning('on','Octave:divide-by-zero');
          xaprox = xk
          iter = k
          if(graf == 1)
            grapher_oc(xVector, yVector, "Anderson-Bjorck's method to: f(x)")
          endif
          return
        endif
        m = 1 - fHandle(xk) / fHandle(xk_1);
        if(m < 0)
          m = 0.5;
        endif
        
        if(sign < 0)
          denominator = fHandle(x1) - m * fHandle(x0);
          if(abs(denominator) == Inf)
            printf(["You can't divide by zero!\nThe process has been ", ...
                    "stopped!\n"]);
            warning('on','Octave:divide-by-zero');
            xaprox = xk
            iter = k
            if(graf == 1)
              grapher_oc(xVector, yVector, "Anderson-Bjorck's method to: f(x)")
            endif
            return
          endif
          xk = (x0 * fHandle(x1) - m * x1 * fHandle(x0)) / denominator;
        else
          denominator = m * fHandle(x1) - fHandle(x0);
          if(abs(denominator) == Inf)
            printf(["You can't divide by zero!\nThe process has been ", ...
                    "stopped!\n"]);
            warning('on','Octave:divide-by-zero');
            xaprox = xk
            iter = k
            if(graf == 1)
              grapher_oc(xVector, yVector, "Anderson-Bjorck's method to: f(x)")
            endif
            return
          endif
          xk = (m * x0 * fHandle(x1) - x1 * fHandle(x0)) / denominator;
        endif
      endif
        
      bolzano = fHandle(x0) * fHandle(xk);
      if(bolzano <= 0)
        xk_1 = x1;
        x1 = xk;
        sign = -1;
      else
        xk_1 = x0;
        x0 = xk;
        sign = 1;
      endif
      
      k = k + 1;
      xVector = [xVector k];
      yVector = [yVector abs(fHandle(xk))];
    endwhile
    
    xaprox = xk
    iter = k
    if(graf == 1)
      grapher_oc(xVector, yVector, "Anderson-Bjorck's method to: f(x)")
    endif
  endif
endfunction
