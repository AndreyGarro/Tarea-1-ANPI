function [x_sig, iteraciones] = sne_ud_5(f, x1, tol, graff = 1)
  pkg load symbolic;
  syms x;
  %{
    Halley's method uses the second derivate of the funtion f to produces iteratively a 
    sequence of approximations to a zero of f.
    The method need one value to start and returns an x approximate and number of 
    iterations that is does.
    
    Reference: D�unic, J. O. V. A. N. A. (2012, August 24). [Halley's method] [Paper]. 
    Retrieved August 20, 2019, from https://link.springer.com/content/pdf/10.1007%2Fs11075-012-9641-3.pdf
        
    Function Format: sne_ud_#(f, x1, tol, graff)
    
    :param x1: (Type FLOAT/INTEGER) Initial Value for x
    :param tol:(Type FLOAT/INTEGER) approach tolerance
    :param f: (Type STRING) math funtion
    :param graff: (Type INTEGER) 1 to shown the graphic and 0 to don't shown
    :return: (Type TUPLE) X approximate and number of iterations
  %}
  f = sym(f);
  variable = symvar(f);
  if (length(variable) > 1)
    disp("Error: The f expression has more than one variables");
    return;
  endif
  if (isempty(find(x == variable)))
    disp("Error: The expression f doesn't have x as a variable");
    return;
  endif
  if(isinteger(x1) == 0 && isfloat(x1) == 0)
    disp("Error: Incorrect initial value");
    return;
  endif
  if(isinteger(tol) == 0 && isfloat(tol) == 0)
    disp("Error: Incorrect tolerance");
    return;    
  endif
  df = diff(f);  
  ddf = diff(df);
  fh = function_handle(f);
  dfh = function_handle(df);
  ddfh = function_handle(ddf);
  if (df == 0 || ddf == 0)
    disp("Error: Derivative equal to zero");
    return;
  endif
  iteraciones = 1;
  divisor = (2 * dfh(x1)**2 - fh(x1) *  ddfh(x1));
  if(divisor == 0)
    disp("Error: Division by zero");
    return;
  endif
  x_sig = x1 - (2 * (fh(x1) * dfh(x1))) / divisor;
  valores_x = [iteraciones];
  valores_y = [abs(fh(x_sig))];
  while(abs(x_sig  - x1) >= tol)
    x1 = x_sig;
    divisor = (2 * dfh(x1)**2 - fh(x1) *  ddfh(x1));
    if(divisor == 0)
      disp("Error: Division by zero");
      return;
    endif
    x_sig = x1 - (2 * (fh(x1) * dfh(x1))) / divisor;
    iteraciones += 1;
    valores_x = [valores_x iteraciones];
    valores_y = [valores_y abs(fh(x_sig))];
  endwhile
  if (graff == 1)
    grapher_oc(valores_x, valores_y, "Halley's method");
  elseif (graff != 0)
    disp("Warning: parameter graff must be an integer, 1 or 0");    
  endif  
endfunction
