function [valorX, iter] = sne_ud_4(fun, a, b, tol, graph)
  %{
  RFN Method
  The RFN method it consists in approximating the root of f, in each step, 
  using the method of the Regula Falsi and the value obtained is used 
  as the initial condition for the Newton-Raphson method.
  
  Retrieved from: Calder�n, G. (2008). M�todos iterativos para resolver 
  ecuaciones no lineales. From: http://webdelprofesor.ula.ve/ciencias/giovanni
  /documentos/Publicaciones/Articulos/NotasMatematicasV32007.pdf
  
  :parameter a: initial value for the interval.
  :parameter b: final value for the interval.
  :parameter fun: math expression to evaluate
  :param tol: minimum approach tolerance
  :param graph: Integer, 1 or 0
  :return: Tuple, [x aproximation, iterations]
  %}
  pkg load symbolic;
  syms x;
  
  if ~(isfloat(a) || isinteger(a) || isinteger(b) || isfloat(b))
    print("Error, interval its not valid")
    return;
  endif;
  if ~(isfloat(tol) || isinteger(tol))
    print("Error, tolerance isn't a valid number");
    return;
  endif
  
  fun = sym(fun);
  variable = symvar(fun);
  if (length(variable) > 1)
    disp("Error: The f expression has more than one variables");
    return;
  endif
  if (isempty(find(x == variable)))
    disp("Error: The expression f doesn't have x as a variable");
    return;
  endif
  
  iterations = 0; 
  fHandler = function_handle(fun);
  dfHandler = function_handle(diff(fun));
  
  a_eval = fHandler(a);
  b_eval = fHandler(b);
  bolzano = a_eval * b_eval;
  denominator = b_eval - a_eval;
  x_values = [iterations];

  if(bolzano > 0)
      print("The existence of one or a single zero in the given interval cannot be guaranteed.");
      return;
  elseif(bolzano == 0)
      if(a_eval == 0)
        y_values = [abs(funHandler(a_eval))];
        valorX = a_eval
        iteration = 0
        return;
      else
        y_values = [abs(funHandler(b_eval))];
        valorX = b_eval
        iteration = 0
        return;
      endif
  endif
  
  if(denominator == 0)
      print("Error, division between zero");
      return;
  endif
  
  z_n = (b * a_eval - a * b_eval) / denominator;
  x_k = z_n - (fHandler(z_n)/ dfHandler(z_n));
  
  y_values = [abs(fHandler(x_k))];
  while(abs(fHandler(x_k)) >= tol)
      if(bolzano < 0)
          b = x_k;
      elseif (bolzano > 0)
          a = x_k;
      endif
      denominator = fHandler(b) - fHandler(a);
      
      if(denominator == 0)
        print("Warning. Division between zero, the x aproximation is: ", x_k);
      break;
      endif;
      
      z_n = b - (fHandler(b) * (b - a))/ (denominator);
      denominator = dfHandler(z_n);
      
      if(denominator == 0)
        print("Warning. Division between zero, the x aproximation is: ", x_k);
      break;
      endif;
      
      x_k = z_n - (fHandler(z_n) / denominator);
      bolzano = fHandler(a) * fHandler(x_k);
      iterations = iterations + 1;
      x_values = [x_values iterations];
      y_values = [y_values abs(fHandler(x_k))];
  endwhile
  if (graph == 1)
    grapher_oc(x_values, y_values, "RFN method to f(x)");
  elseif (graph != 0)
    disp("Warning: parameter graff must be an integer, 1 or 0");    
  endif 
  valorX = x_k
  iter = iterations
 endfunction